package br.futurodev.joinville.trajetocoletaseletivajlle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrajetocoletaseletivaJlleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrajetocoletaseletivaJlleApplication.class, args);
	}

}
