package br.futurodev.joinville.trajetocoletaseletivajlle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrajetocoletaseletivaJlleApplicationTests {

	@Test
	void contextLoads() {
	}

}
